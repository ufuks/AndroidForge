# Gizli Nesne Bulucu v0.3

Bu ZIP, AndroidForge'un Gradle 8.9 ortamına uyum sağlaması için Android Gradle Plugin 8.7.3 ve compileSdk 35 kullanır.

Bu bir başlangıç projesidir; henüz otomatik nesne tanıma ve otomatik hedef seçimi içermez. Ekran yakalama izni akışı ve kullanıcı tarafından etkinleştirilen erişilebilirlik servisi iskeleti vardır.

AndroidForge'da Android APK seçip ZIP'i yükleyerek derlemeyi deneyin. Bu değişiklik Gradle sürüm uyuşmazlığını hedefler; derlemenin başarılı olacağı henüz doğrulanmamıştır.
