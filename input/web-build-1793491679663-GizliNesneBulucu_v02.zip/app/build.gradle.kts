plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.gizlinesne"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.gizlinesne"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.2"
    }
}
