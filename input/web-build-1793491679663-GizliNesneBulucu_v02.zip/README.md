# Gizli Nesne Bulucu — uyumlu derleme başlangıç projesi

Bu ZIP, AndroidForge'un Gradle 8.9 ortamıyla uyumlu olması için Android Gradle Plugin 8.7.3 ve compileSdk 35 kullanır.

Bu bir tamamlanmış nesne bulma uygulaması değildir. Ekran yakalama izni akışı ve erişilebilirlik üzerinden dokunma altyapısı içerir. Otomatik hedef tanıma/eşleştirme motoru henüz eklenmemiştir.

AndroidForge ile Android APK seçerek derlenebilir. Başarılı derleme, yalnızca bu başlangıç uygulamasını üretir.
