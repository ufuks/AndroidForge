# Gizli Nesne Bulucu — Android başlangıç projesi

Bu ZIP, Android Studio'da açılabilen bir **başlangıç iskeletidir**, bitmiş/derlenmiş APK değildir.

## Şu an bulunanlar
- Kotlin Android uygulama kabuğu
- Android MediaProjection kullanıcı izni akışı ve foreground service
- Kullanıcı tarafından etkinleştirilen Accessibility Service
- Doğrulanmış koordinata dokunmak için `tapAt(x, y)` metodu

## Henüz tamamlanmamış kritik parça
Oyun ekranındaki hedefleri otomatik bulacak görüntü eşleştirme motoru henüz eklenmemiştir. Bunun için hedef nesne görsellerinin nasıl sunulduğunu bilmek ve her hedef için ekran görüntüsünden şablon çıkarmak gerekir. Bu nedenle bu sürüm kendi başına nesneleri bulup tıklamaz.

## Android Studio
1. ZIP'i açın ve `GizliNesneBulucu` klasörünü Android Studio ile açın.
2. Gradle senkronizasyonunu tamamlayın.
3. Samsung telefonda USB hata ayıklama açıkken çalıştırın.
4. Uygulama içinden erişilebilirlik servisini kullanıcı olarak etkinleştirin.
5. Ekran yakalama iznini verin.

Ekran yakalama ve otomatik dokunma izinleri Android'in sistem onaylarıyla verilir. Kullanıcı izni olmadan ekran okunmaz veya dokunma yapılmaz.

## Sonraki geliştirme adımı
Oyunda hedef nesneler altta küçük görseller olarak listeleniyorsa, hedef bölgesini ve oyun sahnesini ayırıp OpenCV şablon eşleştirme ile koordinat bulma eklenebilir. Benzer görünümlü nesneler için otomatik tıklamadan önce güven skoru eşiği uygulanmalıdır.
