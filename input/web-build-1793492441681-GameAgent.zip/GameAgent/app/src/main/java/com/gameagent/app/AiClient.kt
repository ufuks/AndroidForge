package com.gameagent.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object AiClient {
    data class Action(
        val type: String,
        val x: Float = 0f, val y: Float = 0f,
        val x2: Float = 0f, val y2: Float = 0f,
        val durationMs: Long = 300,
        val reason: String = ""
    )

    private val http = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val SYSTEM = """You are an agent that plays a mobile game by looking at screenshots and controlling the touchscreen.
Each turn you get ONE screenshot and must answer with exactly ONE JSON object and nothing else.
Coordinates are integers from 0 to 1000 relative to the screenshot (x: left to right, y: top to bottom).
Ignore the small floating blue/red button on the right edge of the screen; it belongs to the controller app.
Allowed actions:
{"action":"tap","x":int,"y":int,"reason":"..."}
{"action":"long_press","x":int,"y":int,"duration_ms":int,"reason":"..."}
{"action":"swipe","x":int,"y":int,"x2":int,"y2":int,"duration_ms":int,"reason":"..."}
{"action":"back","reason":"..."}
{"action":"wait","duration_ms":int,"reason":"..."}
{"action":"done","reason":"..."}  (use when the goal is reached, the game is not on screen, or you are stuck)
Rules: never tap purchase/payment buttons or confirm real-money purchases. Skip or close ads only through their close button. Keep "reason" under 15 words."""

    fun decide(cfg: Config, imageB64: String, history: List<String>): Action {
        val userText = buildString {
            append("Goal: ").append(cfg.goal.ifBlank { "Play the game well and progress." }).append("\n")
            if (history.isNotEmpty()) {
                append("Your last actions (oldest first):\n")
                history.forEach { append("- ").append(it).append("\n") }
            }
            append("Choose the next action.")
        }
        val content = JSONArray()
            .put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject()
                        .put("type", "base64")
                        .put("media_type", "image/jpeg")
                        .put("data", imageB64)
                )
            )
            .put(JSONObject().put("type", "text").put("text", userText))
        val body = JSONObject()
            .put("model", cfg.model)
            .put("max_tokens", 300)
            .put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))

        val req = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", cfg.apiKey)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(req).execute().use { resp ->
            val txt = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IOException("API ${resp.code}: ${txt.take(200)}")
            val arr = JSONObject(txt).getJSONArray("content")
            var text = ""
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                if (b.optString("type") == "text") text += b.optString("text")
            }
            return parse(text)
        }
    }

    private fun parse(text: String): Action {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        if (s < 0 || e <= s) throw IOException("Geçersiz yanıt: ${text.take(100)}")
        val o = JSONObject(text.substring(s, e + 1))
        return Action(
            type = o.optString("action", "wait"),
            x = o.optDouble("x", 500.0).toFloat(),
            y = o.optDouble("y", 500.0).toFloat(),
            x2 = o.optDouble("x2", 500.0).toFloat(),
            y2 = o.optDouble("y2", 500.0).toFloat(),
            durationMs = o.optLong("duration_ms", 300),
            reason = o.optString("reason", "")
        )
    }
}
