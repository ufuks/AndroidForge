package com.gameagent.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var key: EditText
    private lateinit var model: EditText
    private lateinit var goal: EditText
    private lateinit var interval: EditText
    private lateinit var maxSteps: EditText

    private fun field(hint: String, value: String, multiline: Boolean = false) = EditText(this).apply {
        this.hint = hint
        setText(value)
        if (multiline) {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = Prefs.load(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        status = TextView(this).apply { textSize = 15f }
        key = field("Anthropic API anahtarı (sk-ant-...)", cfg.apiKey).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        model = field("Model", cfg.model)
        goal = field("Oyun hedefi (örn. 'Bulmacaları çöz, seviyeleri geç')", cfg.goal, true)
        interval = field("Adımlar arası bekleme (ms)", cfg.intervalMs.toString()).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        maxSteps = field("Maksimum adım (API maliyetini sınırlar)", cfg.maxSteps.toString()).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        val save = Button(this).apply {
            text = "Kaydet"
            setOnClickListener {
                Prefs.save(
                    this@MainActivity, Config(
                        key.text.toString().trim(),
                        model.text.toString().trim().ifBlank { "claude-haiku-5-5" },
                        goal.text.toString().trim(),
                        interval.text.toString().toLongOrNull()?.coerceAtLeast(500) ?: 1500L,
                        maxSteps.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 300
                    )
                )
                Toast.makeText(this@MainActivity, "Kaydedildi", Toast.LENGTH_SHORT).show()
            }
        }
        val access = Button(this).apply {
            text = "Erişilebilirlik ayarlarını aç"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val help = TextView(this).apply {
            text = "Kullanım:\n1) Erişilebilirlik > Game Agent servisini aç.\n" +
                "2) Ayarları kaydet.\n3) Oyunu aç, ekranın sağındaki ▶ AI düğmesine bas.\n" +
                "4) Durdurmak için ■ DUR düğmesine bas.\n\n" +
                "Not: Android 13+ üzerinde APK'yı elle kurduysan Uygulama bilgisi > ⋮ > " +
                "'Kısıtlanmış ayarlara izin ver' adımı gerekebilir."
            textSize = 13f
        }
        listOf(status, key, model, goal, interval, maxSteps, save, access, help).forEach {
            root.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (GameAgentService.instance != null) "Servis: AÇIK ✓" else "Servis: KAPALI ✗ (erişilebilirlikten aç)"
    }
}
