package com.gameagent.app

import android.content.Context

data class Config(
    val apiKey: String,
    val model: String,
    val goal: String,
    val intervalMs: Long,
    val maxSteps: Int
)

object Prefs {
    private const val F = "cfg"
    fun load(c: Context): Config {
        val p = c.getSharedPreferences(F, Context.MODE_PRIVATE)
        return Config(
            apiKey = p.getString("key", "") ?: "",
            model = p.getString("model", "gpt-5.5") ?: "gpt-5.5",
            goal = p.getString("goal", "") ?: "",
            intervalMs = p.getLong("interval", 1500L),
            maxSteps = p.getInt("max", 300)
        )
    }
    fun save(c: Context, cfg: Config) {
        c.getSharedPreferences(F, Context.MODE_PRIVATE).edit()
            .putString("key", cfg.apiKey)
            .putString("model", cfg.model)
            .putString("goal", cfg.goal)
            .putLong("interval", cfg.intervalMs)
            .putInt("max", cfg.maxSteps)
            .apply()
    }
}
