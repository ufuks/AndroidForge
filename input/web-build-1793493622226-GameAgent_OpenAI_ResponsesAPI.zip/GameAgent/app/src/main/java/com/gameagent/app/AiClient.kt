package com.gameagent.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object AiClient {
    data class Action(
        val type: String,
        val x: Float = 0f, val y: Float = 0f,
        val x2: Float = 0f, val y2: Float = 0f,
        val durationMs: Long = 300,
        val reason: String = ""
    )

    private val http = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val SYSTEM = """You are an agent that helps operate a mobile game using screenshots.
Return exactly one JSON object and nothing else.
Coordinates are integers from 0 to 1000 relative to the full screenshot (x left-to-right, y top-to-bottom).
Ignore the small floating controller button on the right edge.
Allowed actions:
{"action":"tap","x":int,"y":int,"reason":"..."}
{"action":"long_press","x":int,"y":int,"duration_ms":int,"reason":"..."}
{"action":"swipe","x":int,"y":int,"x2":int,"y2":int,"duration_ms":int,"reason":"..."}
{"action":"back","reason":"..."}
{"action":"wait","duration_ms":int,"reason":"..."}
{"action":"done","reason":"..."}
Never tap purchase/payment buttons or confirm real-money purchases. Skip/close ads only via their close button. Keep reason under 15 words."""

    fun decide(cfg: Config, imageB64: String, history: List<String>): Action {
        if (cfg.apiKey.isBlank()) throw IOException("OpenAI API anahtarı girilmemiş")
        val userText = buildString {
            append("Goal: ").append(cfg.goal.ifBlank { "Find the listed hidden objects in the game." }).append("\n")
            if (history.isNotEmpty()) {
                append("Recent actions (oldest first):\n")
                history.forEach { append("- ").append(it).append("\n") }
            }
            append("Choose the next action based on the screenshot.")
        }

        val content = JSONArray()
            .put(JSONObject().put("type", "input_text").put("text", userText))
            .put(JSONObject()
                .put("type", "input_image")
                .put("image_url", "data:image/jpeg;base64,$imageB64")
                .put("detail", "high"))

        val input = JSONArray().put(
            JSONObject().put("role", "user").put("content", content)
        )
        val body = JSONObject()
            .put("model", cfg.model.ifBlank { "gpt-5.5" })
            .put("instructions", SYSTEM)
            .put("input", input)
            .put("max_output_tokens", 300)

        val req = Request.Builder()
            .url("https://api.openai.com/v1/responses")
            .header("Authorization", "Bearer ${cfg.apiKey}")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(req).execute().use { resp ->
            val txt = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw IOException("OpenAI API ${resp.code}: ${txt.take(250)}")
            val root = JSONObject(txt)
            val output = root.optJSONArray("output") ?: throw IOException("API yanıtında output bulunamadı")
            val texts = StringBuilder()
            for (i in 0 until output.length()) {
                val item = output.optJSONObject(i) ?: continue
                if (item.optString("type") != "message") continue
                val parts = item.optJSONArray("content") ?: continue
                for (j in 0 until parts.length()) {
                    val part = parts.optJSONObject(j) ?: continue
                    if (part.optString("type") == "output_text") texts.append(part.optString("text"))
                }
            }
            if (texts.isEmpty()) throw IOException("Model metin yanıtı döndürmedi")
            return parse(texts.toString())
        }
    }

    private fun parse(text: String): Action {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        if (s < 0 || e <= s) throw IOException("Geçersiz JSON yanıtı: ${text.take(120)}")
        val o = JSONObject(text.substring(s, e + 1))
        val type = o.optString("action", "wait")
        if (type !in setOf("tap", "long_press", "swipe", "back", "wait", "done")) {
            throw IOException("Bilinmeyen işlem: $type")
        }
        return Action(
            type = type,
            x = o.optDouble("x", 500.0).toFloat(),
            y = o.optDouble("y", 500.0).toFloat(),
            x2 = o.optDouble("x2", 500.0).toFloat(),
            y2 = o.optDouble("y2", 500.0).toFloat(),
            durationMs = o.optLong("duration_ms", 300),
            reason = o.optString("reason", "")
        )
    }
}
