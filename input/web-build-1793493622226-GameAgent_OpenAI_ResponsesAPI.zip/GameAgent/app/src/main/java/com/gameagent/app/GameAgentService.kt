package com.gameagent.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.Toast
import kotlinx.coroutines.*
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

class GameAgentService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GameAgentService? = null
    }

    private class Shot(val b64: String, val w: Int, val h: Int)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val ui = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private var button: Button? = null
    private val history = ArrayDeque<String>()

    override fun onServiceConnected() {
        instance = this
        showOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopAgent("Kesildi") }

    override fun onDestroy() {
        stopAgent(null)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        button?.let { runCatching { wm.removeView(it) } }
        instance = null
        scope.cancel()
        super.onDestroy()
    }

    // ---------- Overlay ----------
    private fun showOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = Button(this).apply {
            text = "▶ AI"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xAA1565C0.toInt())
            setOnClickListener {
                if (job?.isActive == true) stopAgent("Durduruldu") else startAgent()
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        wm.addView(b, lp)
        button = b
    }

    private fun setRunningUi(running: Boolean) = ui.post {
        button?.text = if (running) "■ DUR" else "▶ AI"
        button?.setBackgroundColor(if (running) 0xAAC62828.toInt() else 0xAA1565C0.toInt())
    }

    private fun toast(msg: String) = ui.post { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }

    // ---------- Agent loop ----------
    private fun startAgent() {
        val cfg = Prefs.load(this)
        if (cfg.apiKey.isBlank()) {
            toast("Önce uygulamadan API anahtarını gir")
            return
        }
        history.clear()
        setRunningUi(true)
        toast("Ajan başladı")
        job = scope.launch {
            var steps = 0
            var errors = 0
            try {
                while (isActive && steps < cfg.maxSteps) {
                    val shot = capture()
                    if (shot == null) {
                        delay(1500)
                        continue
                    }
                    val action = try {
                        AiClient.decide(cfg, shot.b64, history.toList())
                    } catch (e: Exception) {
                        errors++
                        toast("Hata: ${e.message?.take(80)}")
                        if (errors >= 5) break
                        delay(3000)
                        continue
                    }
                    errors = 0
                    steps++
                    history.addLast("${action.type}(${action.x.toInt()},${action.y.toInt()}): ${action.reason}")
                    while (history.size > 8) history.removeFirst()
                    if (action.type == "done") {
                        toast("Bitti: ${action.reason}")
                        break
                    }
                    perform(action, shot.w, shot.h)
                    delay(cfg.intervalMs)
                }
                if (steps >= cfg.maxSteps) toast("Adım limiti doldu")
            } finally {
                setRunningUi(false)
            }
        }
    }

    private fun stopAgent(msg: String?) {
        job?.cancel()
        job = null
        setRunningUi(false)
        if (msg != null) toast(msg)
    }

    // ---------- Screenshot ----------
    private suspend fun capture(): Shot? = suspendCancellableCoroutine { c ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                var shot: Shot? = null
                try {
                    val hb = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                    val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (soft != null) {
                        val w = soft.width
                        val h = soft.height
                        val scale = minOf(1f, 1280f / maxOf(w, h))
                        val small = if (scale < 1f)
                            Bitmap.createScaledBitmap(soft, (w * scale).toInt(), (h * scale).toInt(), true)
                        else soft
                        val out = ByteArrayOutputStream()
                        small.compress(Bitmap.CompressFormat.JPEG, 70, out)
                        shot = Shot(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP), w, h)
                    }
                } catch (_: Exception) {
                }
                if (c.isActive) c.resume(shot)
            }

            override fun onFailure(errorCode: Int) {
                if (c.isActive) c.resume(null)
            }
        })
    }

    // ---------- Gestures ----------
    private suspend fun gesture(path: Path, durationMs: Long): Boolean =
        suspendCancellableCoroutine { c ->
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs.coerceAtLeast(1)))
                .build()
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    if (c.isActive) c.resume(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    if (c.isActive) c.resume(false)
                }
            }, null)
            if (!ok && c.isActive) c.resume(false)
        }

    private suspend fun perform(a: AiClient.Action, w: Int, h: Int) {
        fun fx(v: Float) = v.coerceIn(0f, 1000f) / 1000f * w
        fun fy(v: Float) = v.coerceIn(0f, 1000f) / 1000f * h
        when (a.type) {
            "tap" -> gesture(Path().apply { moveTo(fx(a.x), fy(a.y)) }, 50)
            "long_press" -> gesture(
                Path().apply { moveTo(fx(a.x), fy(a.y)) },
                a.durationMs.coerceIn(400, 3000)
            )
            "swipe" -> gesture(
                Path().apply {
                    moveTo(fx(a.x), fy(a.y))
                    lineTo(fx(a.x2), fy(a.y2))
                },
                a.durationMs.coerceIn(150, 2000)
            )
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "wait" -> delay(a.durationMs.coerceIn(200, 5000))
            else -> delay(500)
        }
    }
}
