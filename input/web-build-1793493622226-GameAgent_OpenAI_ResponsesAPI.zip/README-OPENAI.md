# Game Agent — OpenAI API sürümü

Bu kaynak paketi, orijinal GameAgent projesindeki Anthropic Claude API bağlantısını OpenAI Responses API'ye geçirir.

## Önemli
- Bu uygulama ChatGPT mobil uygulamasına doğrudan bağlanmaz; OpenAI API kullanır.
- ChatGPT aboneliği API kredisi içermez. API kullanımı ayrı faturalandırılır.
- API anahtarı uygulamanın yerel SharedPreferences alanında saklanır. Bu prototip anahtarı güvenli bir sunucu kasasında tutmaz; APK'yı başkalarıyla paylaşmayın ve anahtarınızı kimseye göndermeyin.
- Varsayılan model `gpt-5.5` olarak ayarlanmıştır. Hesabınızda bu modele API erişimi yoksa erişebildiğiniz görsel destekli bir model adını girin.
- Ekran görüntüsü OpenAI API'ye gönderilir. Modelin önerdiği dokunma/kaydırma işlemleri erişilebilirlik servisiyle uygulanır. Yanlış dokunma ihtimali vardır; ödeme/satın alma işlemlerinde kullanmayın.

## Derleme
AndroidForge'a bu ZIP'i kaynak proje olarak yükleyip Android (APK) seçin. İlk testte `debug` kullanın.
